Matrix Filling Game 1.0.0 - Windows x64

1. Extract the entire ZIP to a folder on your computer.
2. Open that folder and double-click MatrixFillingGame.exe.

Keep the DLL files, plugins, translations and qt.conf with the application.
The C++ and Qt runtime files are included. No compiler, Qt installation,
Java installation or administrator setup is needed on Windows 10/11 x64.

Getting started
- Click cells to toggle their support. Use 0, 1 or B to set a cell value.
- Press F5 or click Compute to update the selected statistics.
- Use File > Open to load examples/diagonal.mfg.
- Use Ctrl+Z to undo an edit.
- See docs/UserGuide.md for the full controls and file formats.

The command-line programs mfg_analyze.exe, mfg_search.exe and mfg_tools.exe
are also included. Run them from a terminal with --help for instructions.

Optional: the automaton graph preview needs Graphviz's dot program on PATH.
Automaton editing, DOT source and DOT export work without Graphviz.

Third-party notices
Qt 6.6.1 is dynamically linked. Its license texts and component notices are
in licenses/Qt. Qt source is available from https://download.qt.io/archive/qt/6.6/6.6.1/
Microsoft Visual C++ runtime version 14.50.35719 is included app-local.

Application source: https://github.com/chen1088/MatrixFillingGame
